def calc_cart():
    print("Calculate Cart")
