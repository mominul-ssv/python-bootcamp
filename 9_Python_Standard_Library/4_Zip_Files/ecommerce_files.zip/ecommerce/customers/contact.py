def contact_list():
    print("Contact List")
