from ecommerce.customers import contact


def calc_tax():
    print("Calculate Tax")


def calc_shipping():
    print("Calculate Shipping")
